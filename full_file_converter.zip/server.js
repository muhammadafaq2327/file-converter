/**
 * Full File Converter - Backend (Node.js + Express)
 * Features:
 *  - /convert/image            => PNG <-> JPG conversion (use ?target=jpg or png)
 *  - /convert/images-to-pdf    => multiple images -> single PDF
 *  - /convert/video-to-audio   => MP4 -> MP3 extraction
 *
 * Requirements (install on system):
 *  - Node.js (v16+)
 *  - npm
 *  - ffmpeg (for video to audio)
 *
 * Install:
 *   npm install
 *
 * Run:
 *   npm start
 *
 * Note: This server saves uploads to ./tmp and deletes processed files after sending.
 */

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs/promises');
const fsSync = require('fs');
const sharp = require('sharp');
const { PDFDocument } = require('pdf-lib');
const ffmpeg = require('fluent-ffmpeg');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));

// multer setup
const uploadDir = path.join(__dirname, 'tmp');
if (!fsSync.existsSync(uploadDir)) fsSync.mkdirSync(uploadDir);
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g,'_'))
});
const upload = multer({ storage });

// Helpers
async function removeFileSafe(filePath) {
  try { await fs.unlink(filePath); } catch(e){ /* ignore */ }
}

// Image conversion: PNG <-> JPG
app.post('/convert/image', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).send('No file uploaded');
  const target = (req.query.target || 'jpg').toLowerCase();
  const infile = req.file.path;
  const outExt = target === 'png' ? 'png' : 'jpg';
  const outfile = infile + '.' + outExt;

  try {
    // Use sharp for conversion
    const img = sharp(infile);
    if (outExt === 'png') {
      await img.png().toFile(outfile);
    } else {
      await img.jpeg({ quality: 92 }).toFile(outfile);
    }
    res.download(outfile, path.basename(outfile), async () => {
      await removeFileSafe(infile);
      await removeFileSafe(outfile);
    });
  } catch (err) {
    console.error(err);
    await removeFileSafe(infile);
    return res.status(500).send('Conversion failed: ' + err.message);
  }
});

// Images -> PDF (multiple images)
app.post('/convert/images-to-pdf', upload.array('files', 20), async (req, res) => {
  if (!req.files || !req.files.length) return res.status(400).send('No files uploaded');
  const outPath = path.join(uploadDir, `images-to-pdf-${Date.now()}.pdf`);
  try {
    const pdfDoc = await PDFDocument.create();
    for (const f of req.files) {
      const data = await fs.readFile(f.path);
      // Try embedding as JPG, otherwise PNG
      let img;
      try { img = await pdfDoc.embedJpg(data); }
      catch(e) { img = await pdfDoc.embedPng(data); }
      const page = pdfDoc.addPage([img.width, img.height]);
      page.drawImage(img, { x: 0, y: 0, width: img.width, height: img.height });
    }
    const pdfBytes = await pdfDoc.save();
    await fs.writeFile(outPath, pdfBytes);
    res.download(outPath, path.basename(outPath), async () => {
      // cleanup
      for (const f of req.files) await removeFileSafe(f.path);
      await removeFileSafe(outPath);
    });
  } catch (err) {
    console.error(err);
    for (const f of req.files) await removeFileSafe(f.path);
    return res.status(500).send('PDF conversion failed: ' + err.message);
  }
});

// Video -> Audio (MP4 -> MP3)
app.post('/convert/video-to-audio', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).send('No file uploaded');
  const infile = req.file.path;
  const outPath = infile + '.mp3';
  try {
    await new Promise((resolve, reject) => {
      ffmpeg(infile)
        .toFormat('mp3')
        .audioCodec('libmp3lame')
        .on('error', async (err) => {
          console.error('ffmpeg error', err);
          await removeFileSafe(infile);
          reject(err);
        })
        .on('end', () => resolve())
        .save(outPath);
    });
    res.download(outPath, path.basename(outPath), async () => {
      await removeFileSafe(infile);
      await removeFileSafe(outPath);
    });
  } catch (err) {
    console.error(err);
    await removeFileSafe(infile);
    return res.status(500).send('Video->Audio failed: ' + err.message);
  }
});

// Simple health route
app.get('/ping', (req,res)=>res.send('ok'));

app.listen(PORT, ()=> console.log(`Server listening on http://localhost:${PORT}`));
