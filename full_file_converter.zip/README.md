# Full File Converter (Backend + Frontend)

This is a full-stack example project that provides a small backend (Node.js + Express) for file conversions
and a simple static frontend to interact with it.

## Features
- PNG <-> JPG conversion (server-side using `sharp`)
- Multiple Images -> Single PDF (`pdf-lib`)
- MP4 -> MP3 audio extraction (`fluent-ffmpeg` + system `ffmpeg`)
- Simple static frontend in `/public`

## Requirements
- Node.js (v16+)
- npm
- ffmpeg installed on your system (required for video -> audio)

### Installing ffmpeg
#### Windows (using Chocolatey)
```powershell
choco install ffmpeg
```
#### Ubuntu / Debian
```bash
sudo apt update
sudo apt install ffmpeg
```
#### macOS (Homebrew)
```bash
brew install ffmpeg
```

## Setup & Run
1. Clone or extract this project.
2. Install node modules:
```bash
npm install
```
3. Start the server:
```bash
npm start
```
4. Open browser: `http://localhost:3000`

## Notes & Deployment
- This project stores uploaded files temporarily in `./tmp` and deletes them after the conversion download completes.
- For production, use HTTPS and consider file size limits, authentication, rate-limiting, and virus scanning.
- To deploy, use providers like Render, Railway, or a VPS. Ensure `ffmpeg` is available in the environment.

## Troubleshooting
- If `sharp` fails to install, make sure build tools are available on your system (Windows Build Tools or appropriate Linux packages).
- If `fluent-ffmpeg` cannot find ffmpeg, install ffmpeg and ensure it's in your PATH.

